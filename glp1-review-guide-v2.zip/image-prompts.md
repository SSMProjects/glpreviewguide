# GLP-1 Review Guide — v2 Advertorial · Image Prompts

Paste into Midjourney, DALL·E 3, Ideogram, Flux, Leonardo, etc.
Each lists the **slot → filename**, **size/ratio**, the **prompt**, and a **negative prompt**.

**House style:** warm, clean editorial/lifestyle photography. Soft natural light. Subtle plum (#392D3E) / gold (#F5C74D) / cream (#F5EBEC) tones. Realistic, authentic — not glossy stock.

---

## 1. HERO LEFT — "before / candid"  → `images/hero-left.webp`
**Ratio:** 3:4 (portrait)

> Candid, natural photograph of a woman in her early 40s standing outdoors in a park, wearing a casual white t-shirt and black leggings, slightly self-conscious relaxed posture, soft overcast daylight, green grass background, documentary lifestyle style, authentic and un-posed, photorealistic, 50mm.

**Negative:** text, watermark, logos, distorted hands, extra fingers, glamour retouching, weight scale, measuring tape

---

## 2. HERO RIGHT — "after / aspirational"  → `images/hero-right.webp`
**Ratio:** 3:4 (portrait)

> Radiant, confident woman in her early 40s in an elegant off-white dress outdoors by a tree, holding a small bouquet, soft golden sunlight filtering through leaves, happy and self-assured, warm emotional lifestyle photography, photorealistic, shallow depth of field.

**Negative:** text, watermark, logos, distorted hands, over-saturation, plastic skin

> ⚠️ These two form a before/after pair. Before/after weight-loss imagery is **heavily restricted** on Meta/TikTok and by the FTC. Safer options: use two lifestyle images that imply confidence without an explicit body transformation, or keep them clearly generic. Don't pair them with "typical results" claims.

---

## 3. AUTHOR HEADSHOT  → `images/author.webp`
**Ratio:** 1:1 (square, min 400×400) — crops to a circle

> Friendly professional headshot of a woman in her late 30s, warm genuine smile, natural makeup, shoulder-length brown hair, simple blouse, soft neutral studio background, bright even lighting, approachable magazine-contributor look, photorealistic, sharp focus on eyes.

**Negative:** text, watermark, harsh shadows, distorted features, over-retouched

> "Megan Harris" is a pen name in the template — use a consistent author identity you're comfortable standing behind.

---

## 4. PRODUCT IMAGE (sticky Recommended card)  → `images/product.webp`
**Ratio:** 1:1 (square, transparent or cream background)

> Clean product shot of a modern telehealth weight-loss kit on a soft cream surface: a sleek unbranded injectable pen beside a small bottle of dissolvable tablets, minimal premium packaging in plum and gold tones, soft studio lighting, subtle shadow, high-end wellness aesthetic, centered.

**Negative:** real brand names, readable labels, needles pointing at viewer, clutter, text

> ⚠️ Use **unbranded** mockups unless you own the rights. Match the real product your offer ships.

---

## 5. DOCTOR / MEDICAL TEAM  → `images/doctor.webp`
**Ratio:** 4:3 or 3:2

> Photorealistic portrait of a confident board-certified physician in a clean modern clinic, white coat with a stethoscope, warm trustworthy expression, soft daylight, neutral professional background, editorial healthcare photography.

**Negative:** text, readable name badges, fake certificates, distorted hands, logos

> ⚠️ **Compliance:** if your page names a specific doctor as *your* medical lead, use a photo of the **real** physician. An AI person must not be presented as a named real doctor — only as a generic, unnamed "licensed U.S. doctors" visual.

---

## 6. TESTIMONIAL AVATARS ×3  → `images/review1.webp`, `review2.webp`, `review3.webp`
**Ratio:** 1:1 (crops to circle)

> Natural, candid headshot of an everyday woman [vary: early 30s / late 40s / mid 50s], warm authentic smile, casual clothing, soft home or outdoor background, real-person selfie quality (not a polished model), photorealistic. [Generate 3 with different ages, ethnicities and settings.]

**Negative:** text, watermark, studio-perfect model look, distorted faces

> ⚠️ **Important:** do NOT attach AI faces + invented names to quotes and present them as real verified customers — that breaks FTC rules and platform policy and gets accounts banned. Use **real** customers + real quotes (with permission), or keep avatars clearly generic with no "verified buyer" claim.

---

## 7. (Optional) MECHANISM ILLUSTRATION  → `images/science.webp`
**Ratio:** 16:9 or 4:3 — for the DPP-4 section

> Clean modern editorial science illustration: a stylized "message" traveling from the gut to the brain, intercepted and cut off midway, minimalist infographic, soft plum and gold palette on cream, flat vector look, elegant, no text labels.

**Negative:** realistic organs, gore, clutter, hard-to-read text, neon colors

---

## Cheat-sheet
- **Midjourney:** append `--ar 3:4` (hero), `--ar 1:1` (avatars/product), `--style raw --v 6`.
- **DALL·E 3 / Ideogram:** state the ratio in words ("tall 3:4 portrait…").
- **Flux / Leonardo:** paste the negative prompt into the negative field.
- Export as **WebP** (or PNG), put them in an `images/` folder next to `index.html` using the exact filenames above, then replace each dashed placeholder block with `<img src="images/NAME.webp" alt="">`.

## Pre-launch compliance recap
1. Before/after hero — safest to avoid or keep generic; no "typical results".
2. Real doctor photo if named; otherwise generic/unnamed.
3. Real customers + permission for testimonials and their photos.
4. Keep the on-page disclaimer intact.
